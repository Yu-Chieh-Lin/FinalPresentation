var fs = require('fs')
var express = require('express')
var multer = require('multer')
var app = express()
var Tesseract = require('tesseract.js')
var request = require('request')
var async = require('async')




var storage = multer.diskStorage( //設定上傳文件路徑
    {
        destination: './upload/',

        filename: function (req, file, cb) {

            cb(null, file.originalname);
        }
    }
);

app.get('/', (req, res) => {
    res.send("hello")
})

var upload = multer({ storage: storage }).single('imageFile');//添加文件到multer(中間件)對象

app.use(express.static(__dirname, ''));//設置圖片上傳url位置

app.post('/upload', function (req, res) {//upload圖片
    upload(req, res, function (err) {
        if (err) {
            console.log('error occured while uploading')
            return res.end("Error uploading file.")

        } else {
            console.log(req.file)
            console.log("成功傳送")
            // if(req.file){
            const host = req.hostname;
            const filePath = req.protocol + "://" + host + '/' + req.file.path;
            console.log(filePath)
            // app.use(express.static(__dirname, ''));
            var url = 'http://120.126.18.141:8080/upload/' + req.file.originalname;//設定圖片URL

            //辨識
            var filename = 'test.png'
            var writeFile = fs.createWriteStream(filename)

            async function asyncrun() {//定義異步流程
                console.log("async run tesseract start")
                const test = await runtess(url, writeFile, filename, 1000)
                console.log('test: ' + test)
                return test;//runtess's resolve
                // return 'async done' //做標記用
            }
            asyncrun()//異步辨識
                .then(String => {
                    console.log(String);
                    var t = String;


                    //mongo part

                    var MongoClient = require('mongodb').MongoClient;
                    // var XMLHttpRequest = require('xmlhttprequest').XMLHttpRequest;



                    // Connect to the db
                    MongoClient.connect("mongodb://localhost:27017/newapi", { useNewUrlParser: true }, function (err, db) {
                        if (err) throw err;
                        var dbo = db.db("newapi");
                        var mid = [];
                        console.log('connect')
                        dbo.collection("courses").find({}).toArray(function (err, result) {
                            if (err) throw err;
                            for (var r = 0; r < result.length; r++) {
                                for (var q in t) {
                                    if (result[r]['year'] == t[q][0]) {
                                        if (result[r]['semester'] == t[q][1]) {
                                            if (result[r]['coursecode'] == t[q][2]) {
                                                // finaljson.push(result[r].year,result[r].semester,result[r].coursetitle)
                                                mid.push(result[r].year + "," + result[r].semester + "," + result[r].coursetitle + "," + result[r].credit)

                                            } else { continue; }

                                        } else { continue; }
                                    } else {
                                        continue;
                                    }
                                }

                            }
                            var deduped = mid.filter(function (el, i, arr) {
                                return arr.indexOf(el) === i;
                            });
                            function chunk(arr, num) {
                                num = num * 1 || 1;
                                var ret = [];
                                arr.forEach(function (item, i) {
                                    if (i % num === 0) {
                                        ret.push([]);
                                    }
                                    ret[ret.length - 1].push(item);
                                });
                                console.log(ret);
                                return ret;
                            }
                            var ins = chunk(deduped, 1)
                            console.log("ins: ", ins)


                            db.close();
                            res.end(JSON.stringify(ins));
                        });
                    });











                })
                .catch(error => {
                    console.log(error)

                })

            console.log('after asyncrun code executing....')
        };
    });
})


const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {

    console.log(`Server listening on port ${PORT}...`);
});



//設定&返回promise物件 辨識function
function runtess(fileurl, file, image, time) {
    console.log("start to OCR!!!")
    return new Promise(function (resolve, reject) {
        setTimeout(function () {
            request(fileurl).pipe(file).on('close', function () {
                Tesseract.recognize(image, { lang: 'chi_tra' })
                    .progress(function (p) { console.log('progress', p) })
                    .catch(err => console.error(err))
                    .then(function (result) {
                        //只擷取學年學期科目代號
                        var data = result.text.split("\n");
                        var final = [];

                        for (var i in data) {//尋找連續兩個英文字
                            var firsteng = data[i].search("[A-Z]") //第一個英文字
                            if (firsteng < 0) { continue; } //沒有找到英文字則continue
                            else {
                                var outString = data[i].slice(firsteng + 1, data[i].length)
                                //第一個英文字後面的字串塞入outstring
                                var secondeng = outString.search("[A-Z]")
                                if (secondeng != 0) { continue; }//辨別outsting的第一位是否為英文，確定後進入else
                                else {
                                    var test = data[i].slice(firsteng - 6, firsteng + 6).split(" ");
                                    final.push(test);


                                }
                            }
                        }


                        console.log(final);
                        // console.log(array104);
                        resolve(final)//promise成功執行後返回這段
                        reject("辨識發生錯誤，請稍後重新上傳")
                    }, time)
            })
        })

    })

}


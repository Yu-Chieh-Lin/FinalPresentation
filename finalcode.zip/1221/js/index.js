// 如需空白範本的簡介，請參閱下列文件: 
// http://go.microsoft.com/fwlink/?LinkID=397704
// 若要對 cordova-simulate 中頁面載入上或 Android 裝置/模擬器上的程式碼偵錯: 啟動應用程式、設定中斷點、
// 然後在 JavaScript 主控台中執行 "window.location.reload()"。
(function () {
	'use strict';

	var init = function () {                

		var slider2 = new rSlider({
			target: '#slider2',
			values: [0, 1, 2, 3, 4, 5, 6, '7', 8],
			range: false,
			set: [5],
			tooltip: false,
			onChange: function (vals) {
				console.log(vals);
			}
		});

		var slider3 = new rSlider({
			target: '#slider3',
			values: {min: 0, max: 100},
			step: 10,
			range: true,
			set: [10, 40],
			scale: true,
			labels: false,
			onChange: function (vals) {
				console.log(vals);
			}
		});

		var slider = new rSlider({
			target: '#slider',
			values: [2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015],
			range: true,
			set: [2010, 2013],
			onChange: function (vals) {
				console.log(vals);
			}
		});
	};
	window.onload = init;
	function addRow(tableID) {

		var table = document.getElementById(tableID);

		var rowCount = table.rows.length;
		var row = table.insertRow(rowCount);

		var colCount = table.rows[0].cells.length;

		for(var i=0; i<colCount; i++) {

			var newcell	= row.insertCell(i);

			newcell.innerHTML = table.rows[0].cells[i].innerHTML;
			switch(newcell.childNodes[0].type) {
				case "text":
						newcell.childNodes[0].value = "";
						break;
				case "checkbox":
						newcell.childNodes[0].checked = false;
						break;
				case "select-one":
						newcell.childNodes[0].selectedIndex = 0;
						break;
			}
		}
	}

	function deleteRow(tableID, row) {
		var i=row.parentNode.parentNode.rowIndex
		var table = document.getElementById(tableID).deleteRow(i);
	}	
	
	function changeselection(slctid) { 
		var sel1 = document.getElementById(slctid);  	
        var op = sel1.value;  
        switch (op) { 
		case "db":   
            var name = document.getElementById("licname");  
            name.innerHTML = "<option>OCP DBA</option><option>SQL</option>"; 
            break;  
  
        case "pr":  
            var name = document.getElementById("licname");  
            name.innerHTML = "<option>JAVA</option><option>javascript</option><option>C#</option><option>C++</option>";  
            break;  
  
        case "se":  
            var name = document.getElementById("licname");  
            name.innerHTML = "<option>ECSS</option><option>CEH</option><option>ISO27001</option><option>ISO27002</option>";  
            break; 
				
        case "pr2":   
            var name = document.getElementById("progname");  
            name.innerHTML = "<option>C</option><option>java</option><option>javascript</option><option>C#</option><option>C++</option>"; 
            break;  
  
        case "bd":  
            var name = document.getElementById("progname");  
            name.innerHTML = "<option>JAVA</option><option>hadoop</option><option>R</option><option>python</option>";  
            break;   
          }  
    }
		
	function sliderChange(val, teid) {
		var t = document.getElementById(teid);
		t.innerHTML = val;}

	function favourite(x) {
		  document.getElementById(x).classList.toggle('fa-heart-o');
		  document.getElementById(x).classList.toggle('fa-heart');
	}
})();
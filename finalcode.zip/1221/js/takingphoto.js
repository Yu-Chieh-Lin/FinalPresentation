//Taking picture
document.getElementById("TakePic").addEventListener("click",
    function () {
        navigator.camera.getPicture(onSuccess, onFail, {
            quality: 50,
            destinationType: Camera.DestinationType.FILE_URI
            
        });
    });
 
function onSuccess(imageURI) {
    var image = document.getElementById('MyPic');
    image.src = imageURI;   

}
 
function onFail(message) {
    alert('Failed : ' + message);
}
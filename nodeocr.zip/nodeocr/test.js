var t = [['104', '1', 'GD0081'],
['104', '1', 'GE1001'],
['104', '1', 'IM1203']]

var mid = [];


var MongoClient = require('mongodb').MongoClient;
var XMLHttpRequest = require('xmlhttprequest').XMLHttpRequest;
var id = require('mongodb').ObjectID


// Connect to the db
MongoClient.connect("mongodb://localhost:27017/newapi", { useNewUrlParser: true }, function (err, db) {
    if (err) throw err;
    var dbo = db.db("newapi");
    console.log('connect')

    // function matchdb(db) {
        // return new Promise(function (resolve, reject) {
            dbo.collection("courses").find({}).toArray(function (err, result) {
                if (err) throw err;
                for (var r = 0; r < result.length; r++) {
                    for (var q in t) {
                        if (result[r]['year'] == t[q][0]) {
                            if (result[r]['semester'] == t[q][1]) { }
                            if (result[r]['coursecode'] == t[q][2]) {
                                // finaljson.push(result[r].year,result[r].semester,result[r].coursetitle)
                                mid.push(result[r].year + "," + result[r].semester + "," + result[r].coursetitle + "," + result[r].credit)

                            } else { continue; }


                        } else {
                            continue;
                        }
                    }

                }
                var deduped = mid.filter(function (el, i, arr) {
                    return arr.indexOf(el) === i;
                });
                var ins = chunk(deduped, 1)
                console.log("ins: ", ins)

                // console.log(deduped);
            //     resolve(ins)
            //     reject("ERROR, 寫入資料庫時發生錯誤")
            // });

        // })

    // }
    // async function asyncinsert() {
    //     const a = await matchdb();
    //     // console.log("異步結果: ", a)
    //     return a;
    // }
    // asyncinsert()
    //     .then(data => {
    //         console.log(data)
    //         var iidd = id(dbo.collection("users"))
    //         console.log(iidd)

    //         // var OData = JSON.stringify(data);
    //         // var dataid = "OCRtext=" + OData;

    //         // var xhr = new XMLHttpRequest();

    //         // xhr.addEventListener("readystatechange", function () {
    //         //     if (this.readyState === 4) {
    //         //         console.log(this.responseText);
    //         //     }
    //         // });

    //         // xhr.open("POST", "http://120.126.18.141:3000/api/personalize/5c10c27b821c26399506a404");
    //         // xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");


    //         // xhr.send(dataid)

    //     })
    //     .catch(err => {
    //         console.log(err)
    //     })
    db.close();
});
});

function chunk(arr, num) {
    num = num * 1 || 1;
    var ret = [];
    arr.forEach(function (item, i) {
        if (i % num === 0) {
            ret.push([]);
        }
        ret[ret.length - 1].push(item);
    });
    console.log(ret);
    return ret;
}
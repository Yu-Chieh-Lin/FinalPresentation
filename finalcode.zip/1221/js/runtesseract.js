

//Tesseract part

function progressUpdate(packet){	
	var log = document.getElementById("log");
	if(log.firstChild && log.firstChild.status === packet.status){
		if("progress" in packet){
			var progress = log.firstChild.querySelector("progress")
			progress.value = packet.progress
		}
	}else{
		var line = document.createElement("div");
		line.status = packet.status;
		var status = document.createElement("div")
		status.className = "status"
		status.appendChild(document.createTextNode(packet.status))
		line.appendChild(status)
		if("progress" in packet){
			var progress = document.createElement("progress")
			progress.value = packet.progress
			progress.max = 1
			line.appendChild(progress)
		}
		if(packet.status == "done"){
			
			var pre = document.createElement("pre")
			pre.appendChild(document.createTextNode(packet.data.text))
			line.innerHTML = ""
			line.appendChild(pre)
			
		}				
		log.insertBefore(line, log.firstChild)		
	}
				  
}

//辨識
function recognizeFile(file){
	
	
	document.querySelector("#log").innerHTML = ""
	Tesseract.recognize(file, {
		// lang: document.querySelector("#langsel").value
		lang: "chi_tra"
	})
		.progress(function(packet){
			console.info(packet)
			progressUpdate(packet)
		})
		.then(function(data){
			console.log(data)
			progressUpdate({ status: "done", data: data })
		console.log(data.lines);
		
		//清出科目代號
		let final = [];
		for(let i=0;i<data.lines.length;i++){
			var firsteng=data.lines[i].text.search("[A-Z]")
			if(firsteng<0){continue;}
			else{
				var outString = data.lines[i].text.slice(firsteng+1,data.lines[i].text.length)
				
					var secondeng=outString.search("[A-Z]")
					if(secondeng!=0){continue;}
					else{
						var test = data.lines[i].text.slice(firsteng,firsteng+6);
						final.push(test);
					}
				}
		}	
		log.innerHTML=final; //final是清理出來的陣列
        
        
	})
}

